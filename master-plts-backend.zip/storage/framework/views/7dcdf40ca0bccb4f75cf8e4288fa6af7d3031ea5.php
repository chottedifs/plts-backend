

<?php $__env->startSection('content'); ?>
<div class="content">
    <!-- Animated -->
    <div class="animated fadeIn">
        <!--  /Traffic -->
        <div class="clearfix"></div>
        <!-- Orders -->
        <div class="orders">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="box-title"><?php echo e($judul); ?></h4>
                        </div>
                        <div class="card-body">
                            <form method="post" action="<?php echo e(route('master-relasiKios.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="mb-3 col-lg-12">
                                        <label for="kios_id" class="form-label">Pilih Data Kios</label>
                                        <select name="kios_id" id="kios_id" class="form-control <?php $__errorArgs = ['kios_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <option value="" disabled selected hidden>-- Pilih Data Kios --</option>
                                            <?php $__currentLoopData = $banyakKios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($kios->status_kios === 0): ?>
                                                <?php if(old('kios_id') == $kios->id): ?>
                                                    <option value="<?php echo e($kios->id); ?>" selected><?php echo e($kios->nama_kios); ?> || <?php echo e($kios->tempat); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($kios->id); ?>"><?php echo e($kios->nama_kios); ?> || <?php echo e($kios->tempat); ?></option>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['kios_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="mb-3 col-lg-12">
                                        <label for="tarif_kios_id" class="form-label">Pilih Tarif Kios</label>
                                        <select name="tarif_kios_id" id="tarif_kios_id" class="form-control <?php $__errorArgs = ['tarif_kios_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <option value="" disabled selected hidden>-- Pilih Tarif Kios --</option>
                                            <?php $__currentLoopData = $banyakTarifKios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarifKios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(old('tarif_kios_id') == $tarifKios->id): ?>
                                                    <option value="<?php echo e($tarifKios->id); ?>" selected><?php echo e($tarifKios->tipe); ?> || <?php echo e('Rp '.number_format($tarifKios->harga,0,',','.')); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($tarifKios->id); ?>"><?php echo e($tarifKios->tipe); ?> || <?php echo e('Rp '.number_format($tarifKios->harga,0,',','.')); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['tarif_kios_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="mb-3 col-lg-12">
                                        <label for="lokasi_id" class="form-label">Pilih Lokasi Kios</label>
                                        <select name="lokasi_id" id="lokasi_id" class="form-control <?php $__errorArgs = ['lokasi_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <option value="" disabled selected hidden>-- Pilih Lokasi Kios --</option>
                                            <?php $__currentLoopData = $banyakLokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lokasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(old('lokasi_id') == $lokasi->id): ?>
                                                    <option value="<?php echo e($lokasi->id); ?>" selected><?php echo e($lokasi->nama_lokasi); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($lokasi->id); ?>"><?php echo e($lokasi->nama_lokasi); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['lokasi_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="mb-3 col-lg-12">
                                        <label for="use_plts" class="form-label">Menggunakan Listrik</label>
                                        <select name="use_plts" id="use_plts" class="form-control <?php $__errorArgs = ['use_plts'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <option value="" disabled selected hidden>-- Pilih Tipe Listrik --</option>
                                            <option value="1">PLTS(Pembangkit Listrik Tenaga Surya)</option>
                                            <option value="0">PLN(Perusahaan Listrik Negara)</option>
                                        </select>
                                        <?php $__errorArgs = ['use_plts'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </form>
                        </div>
                    </div> <!-- /.card -->
                </div>  <!-- /.col-lg-8 -->
            </div>
        </div>
        <!-- /.orders -->
    <!-- /#add-category -->
    </div>
    <!-- .animated -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alhusadif\Documents\Development\plts-backend\resources\views/pages/admin/relasiKios/create.blade.php ENDPATH**/ ?>