

<?php $__env->startSection('content'); ?>

<div class="breadcrumbs">
    <div class="breadcrumbs-inner">
        <div class="row m-0">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php echo e($judul); ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="">Dashboard</a></li>
                            <li class="active"><?php echo e($judul); ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="content">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('plts')): ?>
                            <div class="float-right">
                                <a href="<?php echo e(route('export-tagihan')); ?>" class="btn btn-success text-right" style="border-radius: 10px;"><i class="fa-solid fa-file-export mr-2"></i> Template Tagihan </a>
                                <button type="button" data-toggle="modal" data-target="#exampleModal" class="btn btn-primary text-right" style="border-radius: 10px;"><i class="fa-solid fa-cloud-arrow-up mr-2"></i>Upload Tagihan</button>
                                
                            </div>
                        <?php endif; ?>
                        <form class="form-inline" action="<?php echo e(route('tagihan-index')); ?>" method="get">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mx-sm-3 mb-2">
                                <label for="bulanTagihan" class="mr-2">Periode Tagihan</label>
                                <input type="month" class="form-control" name="bulanTagihan" id="bulanTagihan" value="<?php echo e(old('bulanTagihan', $periode)); ?>">
                            </div>
                            <div class="form-group mx-sm-3 mb-2">
                                <select name="lokasi" id="lokasi" class="form-control <?php $__errorArgs = ['lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value=" ">-Pilih Lokasi-</option>
                                    <?php $__currentLoopData = $banyakLokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lokasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(old('lokasi') == $lokasi->id): ?>
                                            <option value="<?php echo e($lokasi->id); ?>" selected><?php echo e($lokasi->nama_lokasi); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($lokasi->id); ?>"><?php echo e($lokasi->nama_lokasi); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary mb-2" style="border-radius: 10px;">Cari Tagihan</button>
                        </form>
                    </div>
                    <div class="card-body">
                        
                        <table id="table-datatables" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th class="serial">#</th>
                                    <th>Nama Penyewa</th>
                                    <th>Rekening</th>
                                    <th>Kode Batch</th>
                                    <th>Kode Tagihan</th>
                                    <th>Tanggal Kirim</th>
                                    <th>Tanggal Terima</th>
                                    <th>Status Bayar</th>
                                    <th>Lokasi</th>
                                    <th>Periode</th>
                                    <th>Keterangan</th>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('plts')): ?>
                                        <th class="text-center">Action</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $pembayarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pembayaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="serial"><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($pembayaran->Tagihan->SewaKios->User->nama_lengkap); ?></td>
                                    <td><?php echo e($pembayaran->Tagihan->SewaKios->User->rekening); ?></td>
                                    <td><?php echo e($pembayaran->kode_batch); ?></td>
                                    <td><?php echo e($pembayaran->kode_tagihan); ?></td>
                                    <?php if($pembayaran->tgl_kirim): ?>
                                    <td class="text-center"><?php echo e($pembayaran->tgl_kirim); ?></td>
                                    <?php else: ?>
                                    <td class="text-center">-</td>
                                    <?php endif; ?>
                                    <?php if($pembayaran->tgl_terima): ?>
                                    <td class="text-center"><?php echo e($pembayaran->tgl_terima); ?></td>
                                    <?php else: ?>
                                    <td class="text-center">-</td>
                                    <?php endif; ?>
                                    <td><?php echo e($pembayaran->MasterStatus->nama_status); ?></td>
                                    <td><?php echo e($pembayaran->Lokasi->nama_lokasi); ?></td>
                                    <td><?php echo e(date('M Y', strtotime($pembayaran->periode))); ?></td>
                                    <td><?php echo e($pembayaran->remarks); ?></td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('plts')): ?>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('tagihan.edit', $pembayaran->id)); ?>" class="btn-sm badge-warning" style="font-size: 14px; border-radius:10px;"><i class="fa fa-edit"></i></a>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
</div>

</div>
<?php $__env->stopSection(); ?>



<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Masukan Template Tagihan</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <form action="<?php echo e(route('import-tagihan')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="modal-body">
                <label for="file">Masukan template</label>
                <input type="file" name="import-file" id="import-file" required>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
        </form>
        </div>
    </div>
</div>

<script>
    function kirimData() {
        const bulanTagihan= document.getElementById('periode').value;
        $.ajax({
        method: 'GET',
        url: './export-laporan',
        data: {
            periode: bulanTagihan,
    },
});


    }
</script>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alhusadif\Documents\Development\plts-backend\resources\views/pages/admin/pembayaran/index.blade.php ENDPATH**/ ?>