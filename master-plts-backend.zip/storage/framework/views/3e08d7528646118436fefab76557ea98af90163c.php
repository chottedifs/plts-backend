

<?php $__env->startSection('content'); ?>

<div class="breadcrumbs">
    <div class="breadcrumbs-inner">
        <div class="row m-0">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php echo e($judul); ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="">Dashboard</a></li>
                            <li class="active"><?php echo e($judul); ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="content">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('plts')): ?>
                            <div class="float-right">
                                <a href="<?php echo e(route('export-tagihan')); ?>" class="btn btn-success text-right" style="border-radius: 10px;"><i class="fa-solid fa-file-export mr-2"></i> Template Tagihan </a>
                                <button type="button" data-toggle="modal" data-target="#exampleModal" class="btn btn-primary text-right" style="border-radius: 10px;"><i class="fa-solid fa-cloud-arrow-up mr-2"></i>Upload Tagihan</button>
                                
                            </div>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                            <div class="float-right">
                                <a href="<?php echo e(route('export-tagihan-diskon')); ?>" class="btn btn-success text-right" style="border-radius: 10px;"><i class="fa-solid fa-file-export mr-2"></i> Proses Pembayaran</a>
                            </div>
                        <?php endif; ?>
                        <form class="form-inline" action="<?php echo e(route('historiTagihan')); ?>" method="get">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mx-sm-3 mb-2">
                                <label for="bulanTagihan" class="mr-2">Periode Tagihan</label>
                                <input type="month" class="form-control" name="bulanTagihan" id="bulanTagihan" value="<?php echo e(old('bulanTagihan', $periode)); ?>">
                            </div>
                            <div class="form-group mx-sm-3 mb-2">
                                <select name="status_tagihan" id="status_tagihan" class="form-control <?php $__errorArgs = ['lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="null" disabled selected hidden>Status Tagihan</option>
                                    <option value="0">BELUM TERBAYAR</option>
                                    <option value="1">TERBAYAR</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary mb-2" style="border-radius: 10px;">Cari Tagihan</button>
                        </form>
                    </div>
                    <div class="card-body">
                        
                        <table id="table-datatables" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th class="serial">#</th>
                                    <th>Kode Tagihan</th>
                                    <th>Nama Penyewa</th>
                                    <th>Kios</th>
                                    <th>Lokasi</th>
                                    <th>Total Kwh</th>
                                    <th>Tagihan Kwh</th>
                                    <th>Tagihan Kios</th>
                                    <th>Diskon</th>
                                    <th>Total Tagihan</th>
                                    <th>Periode</th>
                                    <th>Status Bayar</th>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('plts')): ?>
                                        <th class="text-center">Action</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $dataTagihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="serial"><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($tagihan->kode_tagihan); ?></td>
                                    <td><?php echo e($tagihan->SewaKios->User->nama_lengkap); ?></td>
                                    <td><?php echo e($tagihan->SewaKios->RelasiKios->Kios->nama_kios); ?></td>
                                    <td><?php echo e($tagihan->Lokasi->nama_lokasi); ?></td>
                                    <td><?php echo e($tagihan->total_kwh); ?></td>
                                    <td><?php echo e('Rp '.number_format($tagihan->tagihan_kwh,0,',','.')); ?></td>
                                    <td><?php echo e('Rp '.number_format($tagihan->tagihan_kios,0,',','.')); ?></td>
                                    <td><?php echo e($tagihan->diskon); ?>%</td>
                                    <td><?php echo e('Rp '.number_format($tagihan->tagihan_kios - ($tagihan->diskon/100*$tagihan->tagihan_kios)+ $tagihan->tagihan_kwh,0,',','.')); ?></td>
                                    <td><?php echo e(date('M Y', strtotime($tagihan->periode))); ?></td>
                                    <input type="hidden" id="periode" name="periode" value="<?php echo e($tagihan->periode); ?>">
                                    <td class='text-center'>
                                        
                                        <?php if($tagihan->status_bayar == 1): ?>
                                            <p class="badge-success py-2 mb-2" style="border-radius: 10px;">Terbayar</p>
                                        <?php else: ?>
                                            <p class="badge-danger py-2 mb-2" style="border-radius: 10px;">Belum Terbayar</p>
                                        <?php endif; ?>
                                    </td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('plts')): ?>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('tagihan.edit', $tagihan->id)); ?>" class="btn-sm badge-warning" style="font-size: 14px; border-radius:10px;"><i class="fa fa-edit"></i></a>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        
                    </div>
                </div>
            </div>
        </div>
</div>

</div>
<?php $__env->stopSection(); ?>



<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Masukan Template Tagihan</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <form action="<?php echo e(route('import-tagihan')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="modal-body">
                <label for="file">Masukan template</label>
                <input type="file" name="import-file" id="import-file" required>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
        </form>
        </div>
    </div>
</div>

<script>
    function kirimData() {
        const bulanTagihan= document.getElementById('periode').value;
        $.ajax({
        method: 'GET',
        url: './export-laporan',
        data: {
            periode: bulanTagihan,
    },
});


    }
</script>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alhusadif\Documents\Development\plts-backend\resources\views/pages/admin/historiTagihan/index.blade.php ENDPATH**/ ?>