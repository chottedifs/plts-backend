<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                AAAAA
            </div>
            <div class="col-lg-3">
                AAAAA
            </div>
            <div class="col-lg-3">
                BBBBB
            </div>
            <div class="col-lg-3">
                BBBBBB
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Users\alhusadif\Documents\Development\plts-backend\resources\views/pages/admin/tagihan/laporan-tagihan.blade.php ENDPATH**/ ?>