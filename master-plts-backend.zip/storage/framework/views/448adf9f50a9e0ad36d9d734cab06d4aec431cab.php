<table id="bootstrap-data-table" class="table table-striped table-bordered">
    <thead>
        <tr>
            <th class="serial">#</th>
            <th>Nama Penyewa</th>
            <th>Kios</th>
            <th>Lokasi</th>
            <th>Total Kwh</th>
            <th>Tagihan Kwh</th>
            <th>Tagihan Kios</th>
            <th>Total Tagihan</th>
            <th>Periode</th>
            <th>Status Bayar</th>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('plts')): ?>
                <th class="text-center">Action</th>
            <?php endif; ?>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $dataTagihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="serial"><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($tagihan->SewaKios->User->nama_lengkap); ?></td>
            <td><?php echo e($tagihan->SewaKios->RelasiKios->Kios->nama_kios); ?></td>
            <td><?php echo e($tagihan->Lokasi->nama_lokasi); ?></td>
            <td><?php echo e($tagihan->total_kwh); ?></td>
            <td><?php echo e('Rp '.number_format($tagihan->tagihan_kwh,0,',','.')); ?></td>
            <td><?php echo e('Rp '.number_format($tagihan->tagihan_kios,0,',','.')); ?></td>
            <td><?php echo e('Rp '.number_format($tagihan->total_tagihan,0,',','.')); ?></td>
            <td><?php echo e(date('M Y', strtotime($tagihan->periode))); ?></td>
            <td>
                <?php if($tagihan->status_bayar == 1): ?>
                    <div class="badge bg-success text-wrap">
                        Terbayar
                    </div>
                <?php elseif($tagihan->status_bayar == 0): ?>
                    <div class="badge bg-danger text-wrap">
                        Belum Terbayar
                    </div>
                <?php endif; ?>
            </td>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('plts')): ?>
            <td class="text-center">
                <a href="#" class="btn-sm badge-warning" style="font-size: 14px; border-radius:10px;"><i class="fa fa-edit"></i></a>
            </td>
            <?php endif; ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\Users\alhusadif\Documents\Development\plts-backend\resources\views/pages/admin/tagihan/table.blade.php ENDPATH**/ ?>