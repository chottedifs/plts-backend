

<?php $__env->startSection('content'); ?>

<div class="breadcrumbs">
    <div class="breadcrumbs-inner">
        <div class="row m-0">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php echo e($judul); ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="">Dashboard</a></li>
                            <li class="active"><?php echo e($judul); ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="content">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                        <a href="<?php echo e(route('master-relasiKios.create')); ?>" class="btn btn-primary text-right" style="border-radius: 10px;"><i class="fa-solid fa-square-plus mr-2"></i> Kelola Kios</a>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <table id="bootstrap-data-table" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th class="serial">#</th>
                                    <th>Nama Kios</th>
                                    <th>Lokasi Kios</th>
                                    <th>Tipe Kios</th>
                                    <th>Tipe Listrik</th>
                                    <th>Harga Kios</th>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                                    <th class="text-center">Action</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $relasiDataKios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataKios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="serial"><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($dataKios->Kios->nama_kios); ?></td>
                                    <td><?php echo e($dataKios->Lokasi->nama_lokasi); ?></td>
                                    <td><?php echo e($dataKios->TarifKios->tipe); ?></td>
                                    <?php if($dataKios->use_plts == '1'): ?>
                                        <td>PLTS</td>
                                    <?php else: ?>
                                        <td>PLN</td>
                                    <?php endif; ?>
                                    <td><?php echo e('Rp '.number_format($dataKios->TarifKios->harga,0,',','.')); ?></td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('master-relasiKios.edit', $dataKios->id)); ?>" class="btn-sm badge-warning" style="font-size: 14px; border-radius:10px;"><i class="fa fa-edit"></i></a>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
</div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alhusadif\Documents\Development\plts-backend\resources\views/pages/admin/relasiKios/index.blade.php ENDPATH**/ ?>