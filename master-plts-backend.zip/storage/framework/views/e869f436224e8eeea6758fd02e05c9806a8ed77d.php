

<?php $__env->startSection('content'); ?>

<div class="breadcrumbs">
    <div class="breadcrumbs-inner">
        <div class="row m-0">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php echo e($judul); ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="">Dashboard</a></li>
                            <li class="active"><?php echo e($judul); ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="content">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <a href="<?php echo e(route('sewa-kios.create')); ?>" class="btn btn-primary text-right" style="border-radius: 10px;"><i class="fa-solid fa-square-plus mr-2"></i> Sewa kios</a>
                    </div>
                    <div class="card-body">
                        <table id="bootstrap-data-table" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th class="serial">#</th>
                                    <th>Nama Penyewa</th>
                                    <th>Nama Kios</th>
                                    <th>Lokasi Kios</th>
                                    <th>Tipe Listrik</th>
                                    <th>Tipe Kios</th>
                                    <th>Tanggal Sewa</th>
                                    <th>Tanggal Berhenti Sewa</th>
                                    <th>Status Sewa</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $sewaKios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sewa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="serial"><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($sewa->User->nama_lengkap); ?></td>
                                    <td><?php echo e($sewa->RelasiKios->Kios->nama_kios); ?></td>
                                    <td><?php echo e($sewa->RelasiKios->Lokasi->nama_lokasi); ?></td>
                                    <td><?php if($sewa->use_plts == 1): ?>
                                        <?php echo e("PLTS"); ?>

                                        <?php else: ?>
                                        <?php echo e("PLN"); ?>

                                    <?php endif; ?></td>
                                    <td><?php echo e($sewa->RelasiKios->TarifKios->tipe); ?></td>
                                    <td class="text-center"><?php echo e(date('d F Y', strtotime($sewa->tgl_sewa))); ?></td>
                                    <td class="text-center">
                                        <?php if(!$sewa->tgl_akhir_sewa == NULL): ?>
                                        <?php echo e(date('d F Y', strtotime($sewa->tgl_akhir_sewa))); ?>

                                        <?php else: ?>
                                        -
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <?php if($sewa->status_sewa == 1): ?>
                                        <form action="<?php echo e(route('sewa-isActive', $sewa->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-success mb-2" style="border-radius: 10px;">Aktif</button>
                                        </form>
                                        <?php else: ?>
                                        <form action="<?php echo e(route('sewa-isActive', $sewa->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-danger mb-2" style="border-radius: 10px;">Tidak Aktif</button>
                                        </form>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('sewa-kios.edit', $sewa->id)); ?>" class="btn-sm badge-warning" style="font-size: 14px; border-radius:10px;"><i class="fa fa-edit"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
</div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alhusadif\Documents\Development\plts-backend\resources\views/pages/admin/sewaKios/index.blade.php ENDPATH**/ ?>