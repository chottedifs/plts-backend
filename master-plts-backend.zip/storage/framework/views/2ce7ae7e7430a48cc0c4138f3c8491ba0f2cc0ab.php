<link rel="apple-touch-icon" href="<?php echo e(asset('images/logo-sasmita.png')); ?>">
<link rel="shortcut icon" href="<?php echo e(asset('images/logo-sasmita.png')); ?>">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
<link rel="stylesheet" href="<?php echo e(asset('assets/template/assets/css/cs-skin-elastic.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/template/assets/css/lib/datatable/dataTables.bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/template/assets/css/style.css')); ?>">






<?php /**PATH C:\Users\alhusadif\Documents\Development\plts-backend\resources\views/components/dashboard/style.blade.php ENDPATH**/ ?>