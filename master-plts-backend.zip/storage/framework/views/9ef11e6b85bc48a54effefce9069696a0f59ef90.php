

<?php $__env->startSection('content'); ?>

<div class="breadcrumbs">
    <div class="breadcrumbs-inner">
        <div class="row m-0">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php echo e($judul); ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="">Dashboard</a></li>
                            <li class="active"><?php echo e($judul); ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="content">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <a href="<?php echo e(route('master-plts.create')); ?>" class="btn btn-primary text-right" style="border-radius: 10px;"><i class="fa-solid fa-square-plus mr-2"></i> Data PLTS</a>
                    </div>
                    <div class="card-body">
                        <table id="bootstrap-data-table" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th class="serial">#</th>
                                    <th>Nama Lengkap</th>
                                    <th>Jenis Kelamin</th>
                                    <th>Email</th>
                                    <th>NIP</th>
                                    <th>No Handphone</th>
                                    <th>Lokasi</th>
                                    <th>Status User</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $dataPlts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="serial"><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($plts->nama_lengkap); ?></td>
                                    <td><?php echo e($plts->jenis_kelamin); ?></td>
                                    <td><?php echo e($plts->Login->email); ?></td>
                                    <td><?php echo e($plts->nip); ?></td>
                                    <td><?php echo e($plts->no_hp); ?></td>
                                    <td><?php echo e($plts->Lokasi->nama_lokasi); ?></td>
                                    <td>
                                        <?php if($plts->Login->is_active): ?>
                                        <form action="<?php echo e(route('plts-isActive', $plts->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-success mb-2" style="border-radius: 10px;">Aktif</button>
                                        </form>
                                        <?php else: ?>
                                        <form action="<?php echo e(route('plts-isActive', $plts->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-danger mb-2" style="border-radius: 10px;">Tidak Aktif</button>
                                        </form>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('master-plts.edit', $plts->id)); ?>" class="btn-sm badge-warning" style="font-size: 14px; border-radius:10px;"><i class="fa fa-edit"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
</div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alhusadif\Documents\Development\plts-backend\resources\views/pages/admin/plts/index.blade.php ENDPATH**/ ?>